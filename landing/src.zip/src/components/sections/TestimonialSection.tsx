"use client"

import { motion } from "framer-motion"
import { SectionWrapper } from "@/components/shared/SectionWrapper"
import { useLanguage } from "@/lib/landing-i18n"

export function TestimonialSection() {
  const { t } = useLanguage()

  return (
    <SectionWrapper className="bg-[#f7f9fc]">
      <div className="text-center mb-12">
        <p className="text-xs font-bold uppercase tracking-widest text-[#B4B2A9] mb-3">What people say</p>
        <h2 className="font-[var(--font-head)] text-3xl font-bold tracking-tight text-[#042C53] md:text-4xl">
          Real stories, real impact
        </h2>
      </div>
      <div className="mx-auto max-w-5xl grid grid-cols-1 md:grid-cols-2 gap-8 lg:gap-12">
        {t.testimonials.map((item, index) => (
          <motion.div
            key={index}
            className="flex flex-col rounded-2xl border border-[#e4edf7] bg-white p-8 lg:p-10 shadow-[0_2px_12px_rgba(4,44,83,0.06)]"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-80px" }}
            transition={{ duration: 0.6, delay: index * 0.15 }}
          >
            {/* Quote mark */}
            <div className="text-[#EF9F27] text-4xl font-serif leading-none mb-4">&ldquo;</div>
            <blockquote className="flex-1 font-[var(--font-head)] text-lg leading-relaxed tracking-tight text-[#042C53] lg:text-xl">
              {item.quote}
            </blockquote>
            <div className="mt-6 flex items-center gap-3">
              {item.avatar ? (
                <img src={item.avatar} alt={item.author} className="h-10 w-10 shrink-0 rounded-xl object-contain bg-white shadow-sm border border-[#e4edf7]" />
              ) : (
                <div className="h-10 w-10 shrink-0 rounded-full bg-gradient-to-br from-[#EF9F27] to-[#BA7517] flex items-center justify-center text-white font-bold text-sm shadow-sm">
                  {item.author.charAt(0)}
                </div>
              )}
              <div>
                <p className="text-sm font-semibold text-[#042C53]">{item.author}</p>
                <p className="text-xs text-[#B4B2A9]">{item.role}</p>
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </SectionWrapper>
  )
}
