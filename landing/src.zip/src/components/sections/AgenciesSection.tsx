"use client"

import { motion } from "framer-motion"
import { ArrowRight } from "lucide-react"
import { Button } from "@/components/ui/button"
import { agencies } from "@/data/landing-agencies"
import type { Agency } from "@/data/landing-agencies"
import { useLanguage } from "@/lib/landing-i18n"

const rows: Agency[][] = [
  agencies.slice(0, 8),
  agencies.slice(8, 16),
  agencies.slice(16, 24),
]
const tripledRows = rows.map((row) => [...row, ...row, ...row])
const rowOffsets = ["3%", "-2%", "1%", "-3%", "2%", "-1%"]

export function AgenciesSection() {
  const { t } = useLanguage()

  return (
    <section id="about" className="py-10 px-6 bg-[#f7f9fc]">
      <div className="mx-auto max-w-5xl rounded-3xl bg-white overflow-hidden pt-16 pb-0 border border-[#e4edf7] shadow-[0_2px_24px_rgba(4,44,83,0.06)]">
        {/* Header */}
        <div className="text-center px-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-80px" }}
            transition={{ duration: 0.5 }}
          >
            <p className="text-xs font-bold uppercase tracking-widest text-[#B4B2A9] mb-3">Agencies</p>
            <h2 className="font-[var(--font-head)] text-3xl font-bold tracking-tight text-[#042C53] md:text-4xl lg:text-[2.75rem]">
              {t.agencies.heading.split("\n").map((line, i, arr) => (
                <span key={i}>
                  {line}
                  {i < arr.length - 1 && <>{" "}<br className="hidden sm:inline" /></>}
                </span>
              ))}
            </h2>
            <p className="mt-4 text-[#5F5E5A] text-lg max-w-2xl mx-auto leading-relaxed">
              {t.agencies.subtitle}
            </p>
            <Button
              size="lg"
              className="mt-7 rounded-full bg-[#EF9F27] hover:bg-[#BA7517] text-white px-8 py-6 text-base font-semibold gap-2 shadow-none cursor-pointer transition-all duration-200 border-0"
              asChild
            >
              <a href="/">
                {t.agencies.cta} <ArrowRight className="h-4 w-4" />
              </a>
            </Button>
          </motion.div>
        </div>

        {/* Agency pill grid with radial fade */}
        <div
          className="mt-10 overflow-hidden"
          style={{
            maskImage: "radial-gradient(ellipse 70% 65% at 50% 50%, black 20%, transparent 75%)",
            WebkitMaskImage: "radial-gradient(ellipse 70% 65% at 50% 50%, black 20%, transparent 75%)",
          }}
        >
          <div className="flex flex-col items-center gap-4 py-4">
            {tripledRows.map((tripled, i) => (
              <div key={i} className="flex gap-4" style={{ transform: `translateX(${rowOffsets[i]})` }}>
                {tripled.map((agency, j) => (
                  <div
                    key={`${agency.shortName}-${j}`}
                    className="flex shrink-0 items-center gap-3 rounded-full border border-[#e4edf7] bg-[#f7fafd] px-4 py-2.5"
                  >
                    <img
                      src={agency.logo}
                      alt={agency.name}
                      className="h-9 w-9 rounded-full object-cover bg-[#E6F1FB]"
                      loading="lazy"
                    />
                    <span className="text-[15px] font-medium text-[#444441] whitespace-nowrap">
                      {agency.shortName}
                    </span>
                  </div>
                ))}
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
